importX is a utility tool for MODX Revolution to quickly import your CSV formatted values into resources.

You can configure the used separator from the component.

The first line of the CSV data is the heading line, which is used to determine what column needs to be added to what resource fields.

See the Documentation at rtfm.modx.com/display/ADDON/ImportX for more information.
